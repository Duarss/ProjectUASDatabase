﻿namespace Celikoor_Tixycket
{
    partial class FormTambahKonsumen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTambahKonsumen));
            this.buttonSimpan = new System.Windows.Forms.Button();
            this.buttonKeluar = new System.Windows.Forms.Button();
            this.buttonKosongi = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labelRp = new System.Windows.Forms.Label();
            this.textBoxSaldoKonsumen = new System.Windows.Forms.TextBox();
            this.labelGaji = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePickerTglLahirKonsumen = new System.Windows.Forms.DateTimePicker();
            this.radioButtonPerempuanKonsumen = new System.Windows.Forms.RadioButton();
            this.radioButtonLakiKonsumen = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxNoHpKonsumen = new System.Windows.Forms.TextBox();
            this.textBoxPasswordKonsumen = new System.Windows.Forms.TextBox();
            this.labelPassword = new System.Windows.Forms.Label();
            this.textBoxUsernameKonsumen = new System.Windows.Forms.TextBox();
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelTanggalLahir = new System.Windows.Forms.Label();
            this.textBoxIdKonsumen = new System.Windows.Forms.TextBox();
            this.labelKode = new System.Windows.Forms.Label();
            this.textBoxNamaKonsumen = new System.Windows.Forms.TextBox();
            this.labelCari = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonSimpan
            // 
            this.buttonSimpan.BackColor = System.Drawing.Color.Tan;
            this.buttonSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSimpan.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSimpan.ForeColor = System.Drawing.Color.White;
            this.buttonSimpan.Location = new System.Drawing.Point(71, 690);
            this.buttonSimpan.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonSimpan.Name = "buttonSimpan";
            this.buttonSimpan.Size = new System.Drawing.Size(182, 55);
            this.buttonSimpan.TabIndex = 38;
            this.buttonSimpan.Text = "SIMPAN";
            this.buttonSimpan.UseVisualStyleBackColor = false;
            this.buttonSimpan.Click += new System.EventHandler(this.buttonSimpan_Click);
            // 
            // buttonKeluar
            // 
            this.buttonKeluar.BackColor = System.Drawing.Color.Tan;
            this.buttonKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKeluar.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKeluar.ForeColor = System.Drawing.Color.White;
            this.buttonKeluar.Location = new System.Drawing.Point(881, 690);
            this.buttonKeluar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonKeluar.Name = "buttonKeluar";
            this.buttonKeluar.Size = new System.Drawing.Size(182, 55);
            this.buttonKeluar.TabIndex = 39;
            this.buttonKeluar.Text = "KELUAR";
            this.buttonKeluar.UseVisualStyleBackColor = false;
            // 
            // buttonKosongi
            // 
            this.buttonKosongi.BackColor = System.Drawing.Color.Tan;
            this.buttonKosongi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKosongi.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKosongi.ForeColor = System.Drawing.Color.White;
            this.buttonKosongi.Location = new System.Drawing.Point(484, 690);
            this.buttonKosongi.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonKosongi.Name = "buttonKosongi";
            this.buttonKosongi.Size = new System.Drawing.Size(182, 55);
            this.buttonKosongi.TabIndex = 40;
            this.buttonKosongi.Text = "KOSONGI";
            this.buttonKosongi.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Tan;
            this.pictureBox3.Location = new System.Drawing.Point(71, 642);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(992, 12);
            this.pictureBox3.TabIndex = 45;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Tan;
            this.pictureBox2.Location = new System.Drawing.Point(1052, 44);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(11, 610);
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Tan;
            this.pictureBox1.Location = new System.Drawing.Point(72, 44);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(11, 610);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Tan;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(72, 44);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(991, 62);
            this.label3.TabIndex = 42;
            this.label3.Text = "TAMBAH KONSUMEN";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelRp
            // 
            this.labelRp.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRp.Location = new System.Drawing.Point(477, 441);
            this.labelRp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRp.Name = "labelRp";
            this.labelRp.Size = new System.Drawing.Size(46, 55);
            this.labelRp.TabIndex = 64;
            this.labelRp.Text = "Rp";
            this.labelRp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxSaldoKonsumen
            // 
            this.textBoxSaldoKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSaldoKonsumen.Location = new System.Drawing.Point(532, 452);
            this.textBoxSaldoKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSaldoKonsumen.Name = "textBoxSaldoKonsumen";
            this.textBoxSaldoKonsumen.Size = new System.Drawing.Size(304, 32);
            this.textBoxSaldoKonsumen.TabIndex = 63;
            // 
            // labelGaji
            // 
            this.labelGaji.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGaji.Location = new System.Drawing.Point(345, 441);
            this.labelGaji.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelGaji.Name = "labelGaji";
            this.labelGaji.Size = new System.Drawing.Size(106, 55);
            this.labelGaji.TabIndex = 62;
            this.labelGaji.Text = "Saldo:";
            this.labelGaji.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(266, 372);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 55);
            this.label2.TabIndex = 61;
            this.label2.Text = "Tanggal Lahir:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dateTimePickerTglLahirKonsumen
            // 
            this.dateTimePickerTglLahirKonsumen.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerTglLahirKonsumen.Location = new System.Drawing.Point(484, 385);
            this.dateTimePickerTglLahirKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerTglLahirKonsumen.Name = "dateTimePickerTglLahirKonsumen";
            this.dateTimePickerTglLahirKonsumen.Size = new System.Drawing.Size(352, 29);
            this.dateTimePickerTglLahirKonsumen.TabIndex = 60;
            // 
            // radioButtonPerempuanKonsumen
            // 
            this.radioButtonPerempuanKonsumen.AutoSize = true;
            this.radioButtonPerempuanKonsumen.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonPerempuanKonsumen.Location = new System.Drawing.Point(641, 330);
            this.radioButtonPerempuanKonsumen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonPerempuanKonsumen.Name = "radioButtonPerempuanKonsumen";
            this.radioButtonPerempuanKonsumen.Size = new System.Drawing.Size(140, 26);
            this.radioButtonPerempuanKonsumen.TabIndex = 59;
            this.radioButtonPerempuanKonsumen.TabStop = true;
            this.radioButtonPerempuanKonsumen.Text = "Perempuan";
            this.radioButtonPerempuanKonsumen.UseVisualStyleBackColor = true;
            // 
            // radioButtonLakiKonsumen
            // 
            this.radioButtonLakiKonsumen.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonLakiKonsumen.Location = new System.Drawing.Point(482, 328);
            this.radioButtonLakiKonsumen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonLakiKonsumen.Name = "radioButtonLakiKonsumen";
            this.radioButtonLakiKonsumen.Size = new System.Drawing.Size(144, 30);
            this.radioButtonLakiKonsumen.TabIndex = 58;
            this.radioButtonLakiKonsumen.TabStop = true;
            this.radioButtonLakiKonsumen.Text = "Laki-Laki";
            this.radioButtonLakiKonsumen.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(263, 312);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 55);
            this.label1.TabIndex = 57;
            this.label1.Text = "Gender:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNoHpKonsumen
            // 
            this.textBoxNoHpKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNoHpKonsumen.Location = new System.Drawing.Point(482, 259);
            this.textBoxNoHpKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNoHpKonsumen.Name = "textBoxNoHpKonsumen";
            this.textBoxNoHpKonsumen.Size = new System.Drawing.Size(354, 32);
            this.textBoxNoHpKonsumen.TabIndex = 56;
            // 
            // textBoxPasswordKonsumen
            // 
            this.textBoxPasswordKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPasswordKonsumen.Location = new System.Drawing.Point(484, 579);
            this.textBoxPasswordKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxPasswordKonsumen.Name = "textBoxPasswordKonsumen";
            this.textBoxPasswordKonsumen.Size = new System.Drawing.Size(352, 32);
            this.textBoxPasswordKonsumen.TabIndex = 55;
            // 
            // labelPassword
            // 
            this.labelPassword.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPassword.Location = new System.Drawing.Point(305, 568);
            this.labelPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(148, 55);
            this.labelPassword.TabIndex = 54;
            this.labelPassword.Text = "Password:";
            this.labelPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxUsernameKonsumen
            // 
            this.textBoxUsernameKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUsernameKonsumen.Location = new System.Drawing.Point(484, 518);
            this.textBoxUsernameKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxUsernameKonsumen.Name = "textBoxUsernameKonsumen";
            this.textBoxUsernameKonsumen.Size = new System.Drawing.Size(352, 32);
            this.textBoxUsernameKonsumen.TabIndex = 53;
            // 
            // labelUsername
            // 
            this.labelUsername.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsername.Location = new System.Drawing.Point(304, 505);
            this.labelUsername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelUsername.Name = "labelUsername";
            this.labelUsername.Size = new System.Drawing.Size(148, 55);
            this.labelUsername.TabIndex = 52;
            this.labelUsername.Text = "Username:";
            this.labelUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTanggalLahir
            // 
            this.labelTanggalLahir.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTanggalLahir.Location = new System.Drawing.Point(262, 250);
            this.labelTanggalLahir.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTanggalLahir.Name = "labelTanggalLahir";
            this.labelTanggalLahir.Size = new System.Drawing.Size(190, 55);
            this.labelTanggalLahir.TabIndex = 51;
            this.labelTanggalLahir.Text = "No HP:";
            this.labelTanggalLahir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxIdKonsumen
            // 
            this.textBoxIdKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdKonsumen.Location = new System.Drawing.Point(482, 132);
            this.textBoxIdKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxIdKonsumen.Name = "textBoxIdKonsumen";
            this.textBoxIdKonsumen.Size = new System.Drawing.Size(144, 32);
            this.textBoxIdKonsumen.TabIndex = 50;
            // 
            // labelKode
            // 
            this.labelKode.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKode.Location = new System.Drawing.Point(266, 121);
            this.labelKode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelKode.Name = "labelKode";
            this.labelKode.Size = new System.Drawing.Size(187, 55);
            this.labelKode.TabIndex = 49;
            this.labelKode.Text = "Id Konsumen:";
            this.labelKode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxNamaKonsumen
            // 
            this.textBoxNamaKonsumen.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNamaKonsumen.Location = new System.Drawing.Point(482, 196);
            this.textBoxNamaKonsumen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxNamaKonsumen.Name = "textBoxNamaKonsumen";
            this.textBoxNamaKonsumen.Size = new System.Drawing.Size(354, 32);
            this.textBoxNamaKonsumen.TabIndex = 48;
            // 
            // labelCari
            // 
            this.labelCari.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCari.Location = new System.Drawing.Point(243, 185);
            this.labelCari.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCari.Name = "labelCari";
            this.labelCari.Size = new System.Drawing.Size(210, 55);
            this.labelCari.TabIndex = 47;
            this.labelCari.Text = "Nama Konsumen:";
            this.labelCari.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FormTambahKonsumen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 761);
            this.Controls.Add(this.labelRp);
            this.Controls.Add(this.textBoxSaldoKonsumen);
            this.Controls.Add(this.labelGaji);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePickerTglLahirKonsumen);
            this.Controls.Add(this.radioButtonPerempuanKonsumen);
            this.Controls.Add(this.radioButtonLakiKonsumen);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNoHpKonsumen);
            this.Controls.Add(this.textBoxPasswordKonsumen);
            this.Controls.Add(this.labelPassword);
            this.Controls.Add(this.textBoxUsernameKonsumen);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.labelTanggalLahir);
            this.Controls.Add(this.textBoxIdKonsumen);
            this.Controls.Add(this.labelKode);
            this.Controls.Add(this.textBoxNamaKonsumen);
            this.Controls.Add(this.labelCari);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonSimpan);
            this.Controls.Add(this.buttonKeluar);
            this.Controls.Add(this.buttonKosongi);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormTambahKonsumen";
            this.Text = "TIXIE";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonSimpan;
        private System.Windows.Forms.Button buttonKeluar;
        private System.Windows.Forms.Button buttonKosongi;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelRp;
        private System.Windows.Forms.TextBox textBoxSaldoKonsumen;
        private System.Windows.Forms.Label labelGaji;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePickerTglLahirKonsumen;
        private System.Windows.Forms.RadioButton radioButtonPerempuanKonsumen;
        private System.Windows.Forms.RadioButton radioButtonLakiKonsumen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxNoHpKonsumen;
        private System.Windows.Forms.TextBox textBoxPasswordKonsumen;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBoxUsernameKonsumen;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label labelTanggalLahir;
        private System.Windows.Forms.TextBox textBoxIdKonsumen;
        private System.Windows.Forms.Label labelKode;
        private System.Windows.Forms.TextBox textBoxNamaKonsumen;
        private System.Windows.Forms.Label labelCari;
    }
}