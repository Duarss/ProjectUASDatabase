﻿namespace Celikoor_Tixycket
{
    partial class FormUtama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUtama));
            this.menuStripFormUtama = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.konsumenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jENISSTUDIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.gENREToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aktorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.konsumenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pegawaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kelompokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.transaksiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.penjadwalanFilmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pencatatanKedatanganToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laporanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.labelLogInSebagai = new System.Windows.Forms.Label();
            this.buttonLogInOut = new System.Windows.Forms.Button();
            this.menuStripFormUtama.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripFormUtama
            // 
            this.menuStripFormUtama.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStripFormUtama.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStripFormUtama.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripFormUtama.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem6,
            this.masterToolStripMenuItem,
            this.toolStripMenuItem4,
            this.transaksiToolStripMenuItem,
            this.toolStripMenuItem3,
            this.sistemToolStripMenuItem,
            this.toolStripMenuItem5});
            this.menuStripFormUtama.Location = new System.Drawing.Point(0, 0);
            this.menuStripFormUtama.Name = "menuStripFormUtama";
            this.menuStripFormUtama.Padding = new System.Windows.Forms.Padding(6, 1, 0, 1);
            this.menuStripFormUtama.Size = new System.Drawing.Size(2497, 40);
            this.menuStripFormUtama.TabIndex = 0;
            this.menuStripFormUtama.Text = "menuStrip1";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(46, 38);
            this.toolStripMenuItem6.Text = "|";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.konsumenToolStripMenuItem,
            this.studioToolStripMenuItem,
            this.jENISSTUDIOToolStripMenuItem,
            this.toolStripMenuItem1,
            this.gENREToolStripMenuItem,
            this.aktorsToolStripMenuItem,
            this.toolStripMenuItem2,
            this.konsumenToolStripMenuItem1,
            this.pegawaiToolStripMenuItem,
            this.kelompokToolStripMenuItem});
            this.masterToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(256, 38);
            this.masterToolStripMenuItem.Text = "MASTER DATA";
            // 
            // konsumenToolStripMenuItem
            // 
            this.konsumenToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.konsumenToolStripMenuItem.Name = "konsumenToolStripMenuItem";
            this.konsumenToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.konsumenToolStripMenuItem.Text = "CINEMA";
            this.konsumenToolStripMenuItem.Click += new System.EventHandler(this.konsumenToolStripMenuItem_Click);
            // 
            // studioToolStripMenuItem
            // 
            this.studioToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studioToolStripMenuItem.Name = "studioToolStripMenuItem";
            this.studioToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.studioToolStripMenuItem.Text = "STUDIO";
            this.studioToolStripMenuItem.Click += new System.EventHandler(this.studioToolStripMenuItem_Click);
            // 
            // jENISSTUDIOToolStripMenuItem
            // 
            this.jENISSTUDIOToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jENISSTUDIOToolStripMenuItem.Name = "jENISSTUDIOToolStripMenuItem";
            this.jENISSTUDIOToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.jENISSTUDIOToolStripMenuItem.Text = "JENIS STUDIO";
            this.jENISSTUDIOToolStripMenuItem.Click += new System.EventHandler(this.jenisStudioToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(290, 6);
            // 
            // gENREToolStripMenuItem
            // 
            this.gENREToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gENREToolStripMenuItem.Name = "gENREToolStripMenuItem";
            this.gENREToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.gENREToolStripMenuItem.Text = "GENRE";
            this.gENREToolStripMenuItem.Click += new System.EventHandler(this.genreToolStripMenuItem_Click);
            // 
            // aktorsToolStripMenuItem
            // 
            this.aktorsToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aktorsToolStripMenuItem.Name = "aktorsToolStripMenuItem";
            this.aktorsToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.aktorsToolStripMenuItem.Text = "AKTORS";
            this.aktorsToolStripMenuItem.Click += new System.EventHandler(this.aktorsToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(290, 6);
            // 
            // konsumenToolStripMenuItem1
            // 
            this.konsumenToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.konsumenToolStripMenuItem1.Name = "konsumenToolStripMenuItem1";
            this.konsumenToolStripMenuItem1.Size = new System.Drawing.Size(293, 38);
            this.konsumenToolStripMenuItem1.Text = "KONSUMEN";
            this.konsumenToolStripMenuItem1.Click += new System.EventHandler(this.konsumenToolStripMenuItem_Click);
            // 
            // pegawaiToolStripMenuItem
            // 
            this.pegawaiToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pegawaiToolStripMenuItem.Name = "pegawaiToolStripMenuItem";
            this.pegawaiToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.pegawaiToolStripMenuItem.Text = "PEGAWAI";
            this.pegawaiToolStripMenuItem.Click += new System.EventHandler(this.pegawaiToolStripMenuItem_Click);
            // 
            // kelompokToolStripMenuItem
            // 
            this.kelompokToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kelompokToolStripMenuItem.Name = "kelompokToolStripMenuItem";
            this.kelompokToolStripMenuItem.Size = new System.Drawing.Size(293, 38);
            this.kelompokToolStripMenuItem.Text = "KELOMPOK";
            this.kelompokToolStripMenuItem.Click += new System.EventHandler(this.kelompokToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(46, 38);
            this.toolStripMenuItem4.Text = "|";
            // 
            // transaksiToolStripMenuItem
            // 
            this.transaksiToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transaksiToolStripMenuItem.Name = "transaksiToolStripMenuItem";
            this.transaksiToolStripMenuItem.Size = new System.Drawing.Size(262, 38);
            this.transaksiToolStripMenuItem.Text = "TRANSACTION";
            this.transaksiToolStripMenuItem.Click += new System.EventHandler(this.transaksiToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(46, 38);
            this.toolStripMenuItem3.Text = "|";
            // 
            // sistemToolStripMenuItem
            // 
            this.sistemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.penjadwalanFilmToolStripMenuItem,
            this.pencatatanKedatanganToolStripMenuItem,
            this.laporanToolStripMenuItem});
            this.sistemToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sistemToolStripMenuItem.Name = "sistemToolStripMenuItem";
            this.sistemToolStripMenuItem.Size = new System.Drawing.Size(157, 38);
            this.sistemToolStripMenuItem.Text = "SYSTEM";
            // 
            // penjadwalanFilmToolStripMenuItem
            // 
            this.penjadwalanFilmToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.penjadwalanFilmToolStripMenuItem.Name = "penjadwalanFilmToolStripMenuItem";
            this.penjadwalanFilmToolStripMenuItem.Size = new System.Drawing.Size(449, 38);
            this.penjadwalanFilmToolStripMenuItem.Text = "PENJADWALAN FILM";
            this.penjadwalanFilmToolStripMenuItem.Click += new System.EventHandler(this.penjadwalanFilmToolStripMenuItem_Click);
            // 
            // pencatatanKedatanganToolStripMenuItem
            // 
            this.pencatatanKedatanganToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pencatatanKedatanganToolStripMenuItem.Name = "pencatatanKedatanganToolStripMenuItem";
            this.pencatatanKedatanganToolStripMenuItem.Size = new System.Drawing.Size(449, 38);
            this.pencatatanKedatanganToolStripMenuItem.Text = "PENCATATAN KEDATANGAN";
            this.pencatatanKedatanganToolStripMenuItem.Click += new System.EventHandler(this.pencatatanKedatanganToolStripMenuItem_Click);
            // 
            // laporanToolStripMenuItem
            // 
            this.laporanToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laporanToolStripMenuItem.Name = "laporanToolStripMenuItem";
            this.laporanToolStripMenuItem.Size = new System.Drawing.Size(449, 38);
            this.laporanToolStripMenuItem.Text = "LAPORAN";
            this.laporanToolStripMenuItem.Click += new System.EventHandler(this.laporanToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(46, 38);
            this.toolStripMenuItem5.Text = "|";
            // 
            // labelLogInSebagai
            // 
            this.labelLogInSebagai.AutoSize = true;
            this.labelLogInSebagai.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelLogInSebagai.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogInSebagai.Location = new System.Drawing.Point(1845, 5);
            this.labelLogInSebagai.Name = "labelLogInSebagai";
            this.labelLogInSebagai.Size = new System.Drawing.Size(306, 34);
            this.labelLogInSebagai.TabIndex = 2;
            this.labelLogInSebagai.Text = "Logged In As : None";
            // 
            // buttonLogInOut
            // 
            this.buttonLogInOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogInOut.Location = new System.Drawing.Point(2232, -1);
            this.buttonLogInOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonLogInOut.Name = "buttonLogInOut";
            this.buttonLogInOut.Size = new System.Drawing.Size(253, 41);
            this.buttonLogInOut.TabIndex = 5;
            this.buttonLogInOut.Text = "Log in";
            this.buttonLogInOut.UseVisualStyleBackColor = true;
            this.buttonLogInOut.Click += new System.EventHandler(this.buttonLogInOut_Click);
            // 
            // FormUtama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(2497, 844);
            this.Controls.Add(this.buttonLogInOut);
            this.Controls.Add(this.labelLogInSebagai);
            this.Controls.Add(this.menuStripFormUtama);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStripFormUtama;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "FormUtama";
            this.Text = "TIXIE";
            this.Load += new System.EventHandler(this.FormUtama_Load);
            this.menuStripFormUtama.ResumeLayout(false);
            this.menuStripFormUtama.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripFormUtama;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaksiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem konsumenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jENISSTUDIOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gENREToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kelompokToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aktorsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem konsumenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sistemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem penjadwalanFilmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pencatatanKedatanganToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem laporanToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.Label labelLogInSebagai;
        internal System.Windows.Forms.Button buttonLogInOut;
        private System.Windows.Forms.ToolStripMenuItem pegawaiToolStripMenuItem;
    }
}